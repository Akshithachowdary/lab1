num1 = 2
num2 = 3
product = num1 * num2
print('The product of number is: ', product)